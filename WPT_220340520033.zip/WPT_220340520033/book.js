const express = require('express');
const app = express();
const cors = require('cors');

const mysql=require ('mysql12');
const {response}=require('express');
app.arguments(cors());

JSON.stringify(result)

//http:localhost:8081/poc2?xyz=3
 const connection = mysql.createconnection({
     host: 'localhost',
     user: 'dhiraj',
     password: 'cdac',
     database: 'classwork',
     port:3306
 });
 
 app.get('/read', function (req,res) {

     const {bookid}=req.body
     const statment='select * from book where bookid =?'

     connection.query(statment,[bookid],(error,res) =>{
         if (error) {
             res.send(error)
         }
         else{
             res.send(res)
         }

        })
    });

    app.get('/update',function (req,res) {
        const {bookid,price}=req.body
        const statment = 'update book set price = ? where bookid = ?'

        connection.query (statment,[price,bookid],(error,res) => {

            if (error) {
                res.send(error)
            }
            else{
                res.send(res)
            }

        })
    });

    app.listen(8081,function () {
        console.log("server listening at port 8081...");
    });
     

 